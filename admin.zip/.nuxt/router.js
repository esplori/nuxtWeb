import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5f13925d = () => interopDefault(import('../pages/api/index.js' /* webpackChunkName: "pages/api/index" */))
const _4de1095c = () => interopDefault(import('../pages/navigation/index.vue' /* webpackChunkName: "pages/navigation/index" */))
const _d31b73ce = () => interopDefault(import('../pages/source/index.vue' /* webpackChunkName: "pages/source/index" */))
const _445bc7eb = () => interopDefault(import('../pages/api/navigation.js' /* webpackChunkName: "pages/api/navigation" */))
const _24bfd306 = () => interopDefault(import('../pages/post/_id.vue' /* webpackChunkName: "pages/post/_id" */))
const _f29ab1b2 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/api",
    component: _5f13925d,
    name: "api"
  }, {
    path: "/navigation",
    component: _4de1095c,
    name: "navigation"
  }, {
    path: "/source",
    component: _d31b73ce,
    name: "source"
  }, {
    path: "/api/navigation",
    component: _445bc7eb,
    name: "api-navigation"
  }, {
    path: "/post/:id?",
    component: _24bfd306,
    name: "post-id"
  }, {
    path: "/",
    component: _f29ab1b2,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
