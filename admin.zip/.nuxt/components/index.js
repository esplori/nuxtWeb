export { default as HomeFooter } from '../../components/homeFooter.vue'
export { default as HomeHeader } from '../../components/homeHeader.vue'
export { default as SideBar } from '../../components/sideBar.vue'

export const LazyHomeFooter = import('../../components/homeFooter.vue' /* webpackChunkName: "components/homeFooter" */).then(c => c.default || c)
export const LazyHomeHeader = import('../../components/homeHeader.vue' /* webpackChunkName: "components/homeHeader" */).then(c => c.default || c)
export const LazySideBar = import('../../components/sideBar.vue' /* webpackChunkName: "components/sideBar" */).then(c => c.default || c)
